import React from "react";
import BookList from "../components/BookList";

const Home = () => {
  return (
    <main className="p-6 max-w-6xl mx-auto">
      <h1 className="text-3xl font-bold text-white mb-6">📚 Your Library</h1>
      <BookList />
    </main>
  );
};

export default Home;
