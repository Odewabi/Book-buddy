import React, { useState, useEffect } from "react";
import { useBooks } from "../context/BookContext";

const Goals = () => {
  const { books } = useBooks();
  const [goalType, setGoalType] = useState("pages");
  const [duration, setDuration] = useState("weekly");
  const [target, setTarget] = useState("");
  const [goalProgress, setGoalProgress] = useState(0);

  useEffect(() => {
    const progress = books.reduce((acc, book) => acc + (book.progress || 0), 0);
    setGoalProgress(progress);
  }, [books]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const goalData = { goalType, duration, target };
    localStorage.setItem("readingGoal", JSON.stringify(goalData));
    alert("Goal saved!");
  };

  return (
    <div className="max-w-xl mx-auto p-6 text-white">
      <h2 className="text-2xl font-bold mb-4">📈 Set Your Reading Goal</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block">Goal Type:</label>
          <select
            value={goalType}
            onChange={(e) => setGoalType(e.target.value)}
            className="w-full p-2 rounded bg-gray-800"
          >
            <option value="pages">Pages</option>
            <option value="books">Books</option>
          </select>
        </div>
        <div>
          <label className="block">Duration:</label>
          <select
            value={duration}
            onChange={(e) => setDuration(e.target.value)}
            className="w-full p-2 rounded bg-gray-800"
          >
            <option value="weekly">Weekly</option>
            <option value="monthly">Monthly</option>
          </select>
        </div>
        <div>
          <label className="block">Target {goalType}:</label>
          <input
            type="number"
            value={target}
            onChange={(e) => setTarget(e.target.value)}
            className="w-full p-2 rounded bg-gray-800"
          />
        </div>
        <button
          type="submit"
          className="bg-indigo-600 px-4 py-2 rounded hover:bg-indigo-500"
        >
          Save Goal
        </button>
      </form>

      <div className="mt-6 bg-gray-800 p-4 rounded">
        <p className="text-lg font-medium">📚 Current Progress:</p>
        <p>
          You’ve read <strong>{goalProgress}</strong> {goalType} so far this{" "}
          {duration}.
        </p>
      </div>
    </div>
  );
};

export default Goals;
