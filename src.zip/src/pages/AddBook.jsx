import React, { useState } from "react";
import { useBooks } from "../context/BookContext";
import { useNavigate } from "react-router-dom";

const AddBook = () => {
  const { addBook } = useBooks();
  const navigate = useNavigate();

  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [pages, setPages] = useState("");
  const [genre, setGenre] = useState("");
  const [status, setStatus] = useState("Want to Read");

  const handleSubmit = (e) => {
    e.preventDefault();

    const newBook = {
      id: Date.now(),
      title,
      author,
      pages: Number(pages),
      genre,
      progress: 0,
      status,
    };

    addBook(newBook);
    navigate("/");
  };

  return (
    <div className="max-w-xl mx-auto p-6 text-white">
      <h2 className="text-2xl font-bold mb-4">📚 Add a New Book</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          className="w-full p-2 rounded bg-gray-800"
          type="text"
          placeholder="Book Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
        <input
          className="w-full p-2 rounded bg-gray-800"
          type="text"
          placeholder="Author"
          value={author}
          onChange={(e) => setAuthor(e.target.value)}
        />
        <input
          className="w-full p-2 rounded bg-gray-800"
          type="number"
          placeholder="Total Pages"
          value={pages}
          onChange={(e) => setPages(e.target.value)}
          required
        />
        <input
          className="w-full p-2 rounded bg-gray-800"
          type="text"
          placeholder="Genre"
          value={genre}
          onChange={(e) => setGenre(e.target.value)}
        />
        <select
          className="w-full p-2 rounded bg-gray-800"
          value={status}
          onChange={(e) => setStatus(e.target.value)}
        >
          <option>Want to Read</option>
          <option>Currently Reading</option>
          <option>Finished</option>
        </select>
        <button
          type="submit"
          className="bg-indigo-600 px-4 py-2 rounded hover:bg-indigo-500"
        >
          Add Book
        </button>
      </form>
    </div>
  );
};

export default AddBook;
