import React from "react";
import { useBooks } from "../context/BookContext";

const Settings = () => {
  const { darkMode, setDarkMode } = useBooks();

  const handleDarkModeToggle = () => {
    setDarkMode(!darkMode);
  };

  return (
    <div className="max-w-xl mx-auto p-6">
      <h2 className="text-2xl font-semibold mb-4 text-white">Settings</h2>

      <div className="space-y-4">
        {/* Dark Mode Toggle */}
        <div className="flex items-center">
          <input
            type="checkbox"
            checked={darkMode}
            onChange={handleDarkModeToggle}
            className="h-5 w-5 text-blue-600 border-gray-300 rounded focus:ring-2 focus:ring-blue-600"
          />
          <label htmlFor="darkMode" className="ml-3 text-white">
            Dark Mode
          </label>
        </div>
      </div>
    </div>
  );
};

export default Settings;
