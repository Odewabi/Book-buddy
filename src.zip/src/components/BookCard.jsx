import React from "react";
import { useBooks } from "../context/BookContext";
import {
  BookOpenIcon,
  BookmarkIcon,
  CheckCircleIcon,
  TrashIcon,
} from "@heroicons/react/24/solid";

const BookCard = ({ book }) => {
  const { updateProgress, removeBook } = useBooks();

  const handleProgressChange = (e) => {
    const newProgress = parseInt(e.target.value);
    const isFinished = newProgress >= book.pages;
    const updatedBook = {
        ...book,
        progress: isFinished ? book.pages : newProgress,
        status: isFinished ? "Finished" : "Currently Reading",
        };
    updateProgress(book.id, updatedBook.progress);
  };

  const getIcon = (status) => {
    switch (status) {
      case "Currently Reading":
        return <BookOpenIcon className="h-5 w-5 text-yellow-400" />;
      case "Want to Read":
        return <BookmarkIcon className="h-5 w-5 text-blue-400" />;
      case "Finished":
        return <CheckCircleIcon className="h-5 w-5 text-green-400" />;
      default:
        return null;
    }
  };

  return (
    <div className="bg-zinc-800 p-4 rounded-xl shadow-md text-white space-y-2">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-semibold">{book.title}</h3>
        {getIcon(book.status)}
      </div>
      <p className="text-sm text-zinc-300">Author: {book.author}</p>
      <p className="text-sm text-zinc-300">Genre: {book.genre}</p>
      <p className="text-sm text-zinc-400 italic">Status: {book.status}</p>

      <div className="space-y-1">
        <label htmlFor={`progress-${book.id}`} className="text-sm text-zinc-400">
          Progress: {book.progress}/{book.pages} pages
        </label>
        <input
          id={`progress-${book.id}`}
          type="range"
          min="0"
          max={book.pages}
          value={book.progress}
          onChange={handleProgressChange}
          className="w-full"
        />
        <div className="h-2 bg-zinc-700 rounded">
          <div
            className="h-2 bg-indigo-500 rounded"
            style={{
              width: `${Math.min((book.progress / book.pages) * 100, 100)}%`,
            }}
          ></div>
        </div>
      </div>

      <button
        onClick={() => removeBook(book.id)}
        className="mt-2 flex items-center gap-2 bg-red-600 hover:bg-red-500 text-white px-3 py-1 rounded"
      >
        <TrashIcon className="h-4 w-4" />
        Remove
      </button>
    </div>
  );
};

export default BookCard;
