import React from "react";
import { Link } from "react-router-dom";
import { useBooks } from "../context/BookContext";

const Header = () => {
  const { isDarkMode, toggleDarkMode } = useBooks();

  return (
    <header className="flex flex-col md:flex-row items-center justify-between p-4 bg-gray-900 text-white shadow-md">
      <div className="flex items-center gap-2 text-2xl font-bold">
        📚 BookBuddy
      </div>

      <nav className="flex gap-4 mt-2 md:mt-0">
        <Link to="/" className="hover:text-indigo-400 transition">
          Home
        </Link>
        <Link to="/add" className="hover:text-indigo-400 transition">
          Add Book
        </Link>
        <Link to="/goals" className="hover:text-indigo-400 transition">
          Goals
        </Link>
        <Link to="/settings" className="hover:text-indigo-400 transition">
          Settings
        </Link>
      </nav>

    </header>
  );
};

export default Header;
