import React from "react";
import { useBooks } from "../context/BookContext";
import BookCard from "./BookCard";

const BookList = () => {
  const { books } = useBooks();

  const categories = ["Currently Reading", "Want to Read", "Finished"];

  return (
    <div className="space-y-10">
      {categories.map((category) => {
        const booksInCategory = books.filter((book) => book.status === category);

        if (booksInCategory.length === 0) return null;

        return (
          <div key={category}>
            <h2 className="text-2xl font-bold text-white mb-4">
              {category === "Currently Reading" && "📖 "}
              {category === "Want to Read" && "🔖 "}
              {category === "Finished" && "✅ "}
              {category}
            </h2>
            <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3">
              {booksInCategory.map((book) => (
                <BookCard key={book.id} book={book} />
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default BookList;
